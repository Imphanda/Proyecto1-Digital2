/* 
 * File:   ADC2.h
 * Author: Nancy Mazariegos
 *
 * Created on May 11, 2020, 8:05 PM
 */

#ifndef ADC2_H
#define	ADC2_H

#include <xc.h>
#include<stdint.h>


uint8_t Control;
uint8_t Registro;
uint8_t Rojo;
uint8_t Verde;
uint8_t Azul;

void ConfInitADC1(void);
void ConfInitADC2(void);
void ConfInitADC3(void);

#endif	/* ADC2_H */

