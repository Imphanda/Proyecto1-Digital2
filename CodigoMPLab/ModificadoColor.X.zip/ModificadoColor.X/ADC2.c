#include <xc.h>
#include<stdint.h>
#include "ADC2.h"

void ConfInitADC1(void){// Se definen los puertos de entrada y salida
//    //----------------------------------4Mhz------------------------------------
//    OSCCON=0b1100001;
    
    //--------------------------------ADC --------------------------------------
    ADCON0bits.ADCS1 = 0;
    ADCON0bits.ADCS0 =1;
    ADCON0bits.CHS3 = 1;//PORTB 2
    ADCON0bits.CHS2 = 0;
    ADCON0bits.CHS1 = 0;
    ADCON0bits.CHS0 = 0;
    ADCON0bits.GO_DONE =1;
    ADCON0bits.ADON = 1; //ADC Puerto de Entrada AN8
    ADCON1bits.ADFM=0;
    ADCON1bits.VCFG0=0;
    ADCON1bits.VCFG1=0;//Justificado izquierda
    ANSEL=0;
    ANSELH = 0b00000001;
    
    
    //-----------------------------PUERTOS--------------------------------------
    
    TRISA = 0;//Verificar Funcionamiento
    TRISB = 0b11111111;//Temperatura-Potenciometro
    TRISD=0;
    
    OPTION_REG=0b00000000;//***

    PORTA=0;
    PORTD=0;

}


void ConfInitADC2(void){// Se definen los puertos de entrada y salida
//    //----------------------------------4Mhz------------------------------------
//    OSCCON=0b1100001;
    
    //--------------------------------ADC --------------------------------------
    ADCON0bits.ADCS1 = 0;
    ADCON0bits.ADCS0 =1;
    ADCON0bits.CHS3 = 1;//PORTB 2
    ADCON0bits.CHS2 = 0;
    ADCON0bits.CHS1 = 0;
    ADCON0bits.CHS0 = 1;
    ADCON0bits.GO_DONE =1;
    ADCON0bits.ADON = 1; //ADC Puerto de Entrada AN9
    ADCON1bits.ADFM=0;
    ADCON1bits.VCFG0=0;
    ADCON1bits.VCFG1=0;//Justificado izquierda
    ANSEL=0;
    ANSELH = 0b00000001;
    
    
    //-----------------------------PUERTOS--------------------------------------
    
    TRISA = 0;//Verificar Funcionamiento
    TRISB = 0b11111111;//Temperatura-Potenciometro
    TRISD=0;
    
    OPTION_REG=0b00000000;//***

    PORTA=0;
    PORTD=0;

}


void ConfInitADC3(void){// Se definen los puertos de entrada y salida
//    //----------------------------------4Mhz------------------------------------
//    OSCCON=0b1100001;
    
    //--------------------------------ADC --------------------------------------
    ADCON0bits.ADCS1 = 0;
    ADCON0bits.ADCS0 =1;
    ADCON0bits.CHS3 = 1;//PORTB 2
    ADCON0bits.CHS2 = 0;
    ADCON0bits.CHS1 = 1;
    ADCON0bits.CHS0 = 0;
    ADCON0bits.GO_DONE =1;
    ADCON0bits.ADON = 1; //ADC Puerto de Entrada AN10
    ADCON1bits.ADFM=0;
    ADCON1bits.VCFG0=0;
    ADCON1bits.VCFG1=0;//Justificado izquierda
    ANSEL=0;
    ANSELH = 0b00000001;
    
    
    //-----------------------------PUERTOS--------------------------------------
    
    TRISA = 0;//Verificar Funcionamiento
    TRISB = 0b11111111;//Temperatura-Potenciometro
    TRISD=0;
    
    OPTION_REG=0b00000000;//***

    PORTA=0;
    PORTD=0;

}

