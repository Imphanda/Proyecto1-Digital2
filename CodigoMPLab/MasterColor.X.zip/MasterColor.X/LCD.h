/* 
 * File:   LCD.h
 * Author: Nancy Mazariegos
 *
 * Created on February 25, 2020, 11:22 AM
 */

#ifndef LCD_H
#define	LCD_H

#include <xc.h> // include processor files - each processor file is guarded.
#include<stdint.h>


#ifndef _XTAL_FREQ
#define _XTAL_FREQ 8000000
#endif

#ifndef RS
#define RS RB6
#endif

#ifndef EN
#define EN RB7
#endif

#ifndef RW
#define RW RB0
#endif

#ifndef PORT_LCD
#define PORT_LCD PORTD
#endif


void Lcd_Port(char a);

void Lcd_Cmd(unsigned char a);

void Lcd_Clear(void);

void Lcd_Set_Cursor(char a, char b);

void Lcd_Init(void);

void Lcd_Write_Char(unsigned char a);

void Lcd_Write_String(char *a);

void Lcd_Shift_Right(void);

void Lcd_Shift_Left(void);



#endif	/* LCD_H */

