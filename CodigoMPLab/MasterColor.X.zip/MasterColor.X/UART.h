/* 
 * File:   UART.h
 * Author: Nancy Mazariegos
 *
 * Created on May 12, 2020, 7:52 PM
 */

#ifndef UART_H
#define	UART_H

void UART_init()
{
    TRISCbits.TRISC7 = 0;   //RX input
    TRISCbits.TRISC6 = 1;   //TX output 
    TXSTAbits.SYNC = 0;     //UART
    TXSTAbits.TX9 = 0;      //8 BITS
    TXSTAbits.BRGH = 0;     //LOW
    SPBRG = 12;            //9600 a 8MHZ
    RCSTAbits.SPEN = 1;     //UART on    
    TXSTAbits.TXEN = 1;    //TX on
    RCSTAbits.CREN = 1;     //RX on
    
}

char UART_read(void)
{
    if (PIR1bits.RCIF == 1)
        return RCREG;
    else
        return 0;
}

void UART_write(char dato)
{
    while (TXSTAbits.TRMT == 0){}
    TXREG = dato;
}

void UART_printf(unsigned char *cadena)
{
    while(*cadena !=0x00){
        UART_write(*cadena);
        cadena++;
    }
}



#endif	/* UART_H */

