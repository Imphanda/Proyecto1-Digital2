//------------------------------------------------------------------------------
//                                                                             *
//    Filename:      Lab5.c                                                    *
//    Fecha:         25/02/2020                                                *
//    Version:       v.1                                                       *
//    Author:        Nancy Alejandra Mazariegos                                *
//    Carnet:        17227                                                     *
//    Description:   Laboratorio 5                                             *
//                                                                             *
//------------------------------------------------------------------------------
// PIC16F887 Configuration Bit Settings

//C�digo del Maestro I2C

// CONFIG1
#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = ON       // RE3/MCLR pin function select bit (RE3/MCLR pin function is MCLR)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>
#define _XTAL_FREQ 8000000//Reloj interno 8Mhz
#include<stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "I2C.h"
#include "LCD.h"
#include "UART.h"
//#include "SPIRasp.h"

int Color;
uint8_t ControlU;
int SensoresIR;
char Envio;
int Temperatura;
int Distancia;
char ColorC[20];
char DistanciaC[20];
char SensoresIRC[20];
char TemperaturaC[20];
char DistanciaC[20];
void Setup(void);
void MandarUART(void);



void main(void) {
   
    Setup();
     UART_init();
    Lcd_Init();
    Lcd_Clear(); 
    __delay_ms(250);
    
    while(1){
    Lcd_Set_Cursor(1,1);
    Lcd_Write_String("RGB");
    Lcd_Set_Cursor(1,5);
    Lcd_Write_String("TeC");
    Lcd_Set_Cursor(1,9);
    Lcd_Write_String("EnB");
    Lcd_Set_Cursor(1,13);
    Lcd_Write_String("FULL");
    
    

    I2C_Master_Start();
    I2C_Master_Write(0x91);
    Color=I2C_Master_Read(0);
    I2C_Master_Stop();
    __delay_ms(10);
    itoa(ColorC,Color,10);
    if (Color ==1){
        Lcd_Set_Cursor(2,1);
        Lcd_Write_String("Verd");
       // itoa(TemperaturaC,Temperatura,10);       //COnvertir variable en String 
    }    
    else if (Color ==2){
        Lcd_Set_Cursor(2,1);
        Lcd_Write_String("Azul");
       // itoa(TemperaturaC,Temperatura,10);       //COnvertir variable en String 
    }
    else if (Color ==3){
        Lcd_Set_Cursor(2,1);
        Lcd_Write_String("Rojo");
       // itoa(TemperaturaC,Temperatura,10);       //COnvertir variable en String 
    }
    else{
        Lcd_Set_Cursor(2,1);
        Lcd_Write_String("N--A");
    }
    I2C_Master_Start();
    I2C_Master_Write(0x81);
    Temperatura=I2C_Master_Read(0);
    I2C_Master_Stop();
    __delay_ms(10);
    
    itoa(TemperaturaC,Temperatura,10);       //COnvertir variable en String 
    Lcd_Set_Cursor(2,6);
    Lcd_Write_String(TemperaturaC);
    
     I2C_Master_Start();
    I2C_Master_Write(0x51);
    Distancia=I2C_Master_Read(0);
    I2C_Master_Stop();
    __delay_ms(10);
    itoa(DistanciaC,Distancia,10);
    if (Distancia >12){
        Lcd_Set_Cursor(2,13);
        Lcd_Write_String("FULL");
       // itoa(TemperaturaC,Temperatura,10);       //COnvertir variable en String 
    }    
    else if (Distancia<=12){
        Lcd_Set_Cursor(2,13);
        Lcd_Write_String("NOTY");
       // itoa(TemperaturaC,Temperatura,10);       //COnvertir variable en String 
    }
    
    I2C_Master_Start();
    I2C_Master_Write(0x71);
    SensoresIR=I2C_Master_Read(0);
    I2C_Master_Stop();
    __delay_ms(10);
    
        itoa(SensoresIRC,SensoresIR,10); 
    if (SensoresIR ==1){
        Lcd_Set_Cursor(2,9);
        Lcd_Write_String("ON ");
       // itoa(TemperaturaC,Temperatura,10);       //COnvertir variable en String 
    }    
    else if (SensoresIR ==2){
        Lcd_Set_Cursor(2,9);
        Lcd_Write_String("SRV");
       // itoa(TemperaturaC,Temperatura,10);       //COnvertir variable en String 
    }
    else if (SensoresIR ==3){
        Lcd_Set_Cursor(2,9);
        Lcd_Write_String("STP");
       // itoa(TemperaturaC,Temperatura,10);       //COnvertir variable en String 
    }
    else{
        Lcd_Set_Cursor(2,9);
        Lcd_Write_String("OFF");
    }
    MandarUART();
    }

    }
void Setup(void){
    //----------------------------------8Mhz------------------------------------
   //Oscilador interno
     OSCCON=0b1110001;
     
    //-----------------------------PUERTOS-------------------------------------- 
    TRISA=0;//Data de LCD
    TRISE=0;//Habilitar LCD
    TRISB = 0;//
    TRISD=0;
    TRISCbits.TRISC3=1;
    TRISCbits.TRISC4=1;
    TRISBbits.TRISB6 = 0;//RS y RW de LCD.
    TRISBbits.TRISB7=0;
    
    PORTB = 0;
    PORTD = 0;
    PORTA=0;
    PORTE=0;
    PORTD=0;  
    
    //----------------------------Interrupciones--------------------------------
    ANSEL = 0;
    ANSELH = 0;
    ControlU=0;
    
    I2C_Master_Init(100000);        // Inicializar Comuncaci�n I2C
    //Valor para determinar SSPADD

}

void MandarUART(void){
        if (ControlU == 0){
        UART_write(Color); 
        ControlU = 1;
        }
        else if (ControlU == 1){
        UART_write(Temperatura);
        ControlU = 2;
        }
        else if (ControlU == 2){
        UART_write(SensoresIR);
        ControlU = 3;
        }
        else if (ControlU == 3){
        UART_write(Distancia);
        ControlU = 0;
        }
}



