//------------------------------------------------------------------------------
//                                                                             *
//    Filename:      Sustituto.c                                               *
//    Fecha:         25/02/2020                                                *
//    Version:       v.1                                                       *
//    Author:        Nancy Alejandra Mazariegos                                *
//    Carnet:        17227                                                     *
//    Description:   Proyecto 1                                                *
//                                                                             *
//------------------------------------------------------------------------------
//*****************************************************************************
// Palabra de configuraci�n
//*****************************************************************************
// CONFIG1
#pragma config FOSC = EXTRC_NOCLKOUT// Oscillator Selection bits (RCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, RC on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

#include <xc.h>
#include<stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "UART.h"
#include "SPI.h"
#define _XTAL_FREQ 8000000//Reloj interno 8Mhz

    int n, dato_rx;
    int envio;
    int color;
    int temp;
    int ult;
    int estado;
    uint8_t ControlU;

    void inicio(void);
    void MandarSPI(void);

void main(void) {
   

    TRISB=0;
    PORTB = 0;
    inicio();
    UART_init();
    
    while(1)
    {
      if(RCIF){
        dato_rx = UART_read();
       if (n == 0){
          color = dato_rx;
          n=1; 
      }
      else if (n == 1){
          temp = dato_rx;
          n=2;
      }
      else if (n == 2){
          estado = dato_rx;
          n=3;
      }
      else if (n == 3){
          ult = dato_rx;
          n = 0;
      }
      else{
          n=0;
      }
      }
      
      PORTB=color;
      PORTD=estado;
      PORTCbits.RC2 = 0; 
       __delay_ms(1);
       
       MandarSPI();
        
       
       __delay_ms(1);
       PORTCbits.RC2 = 1; 
       
    }
    }



void inicio(void){
    ANSEL = 0;
    ANSELH = 0; 
    TRISC2 = 0;
    PORTCbits.RC2 = 1;
    TRISB=0;
    TRISD=0;
    PORTB=0;
    PORTD=0;
    ControlU=0;
    n=0;
    spiInit(SPI_MASTER_OSC_DIV4, SPI_DATA_SAMPLE_MIDDLE, SPI_CLOCK_IDLE_LOW, SPI_IDLE_2_ACTIVE); //Inicializacion del SPI
}

void MandarSPI(void){
    if (ControlU == 0){
        spiWrite(color); 
        ControlU = 1;
        }
        else if (ControlU == 1){
        spiWrite(temp);
        ControlU = 2;
        }
        else if (ControlU == 2){
        spiWrite(estado);
        ControlU = 3;
        }
        else if (ControlU == 3){
        spiWrite(ult);
        ControlU = 0;
        }
}