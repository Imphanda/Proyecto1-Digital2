/* 
 * File:   UART.h
 * Author: Nancy Mazariegos
 *
 * Created on May 12, 2020, 7:52 PM
 */

#ifndef UART_H
#define	UART_H

void UART_init()
{
    TXSTAbits.SYNC = 0;     //UART
    TXSTAbits.TX9 = 0;      //8 BITS
    TXSTAbits.BRGH = 0;     //ALTA VELOCIDAD
    SPBRG = 12;            //9600 a 20MHZ
    RCSTAbits.SPEN = 1;     //UART on    
    TXSTAbits.TXEN = 1;    //TX on
    RCSTAbits.CREN = 1;     //RX on
    RCSTAbits.RX9 = 0;     //RX on
}


char UART_read(void)
{
    while(!RCIF);
    return RCREG;
}

void UART_write(char dato)
{
    TXREG = dato;
     while(TXSTAbits.TRMT == 0);
}

void UART_printf(unsigned char *cadena)
{
    while(*cadena !=0x00){
        UART_write(*cadena);
        cadena++;
    }
}
void UART_Inicio(void){
    TXSTAbits.SYNC = 0;
    TXSTAbits.BRGH = 0;
    BAUDCTLbits.BRG16 = 1;
    SPBRG = 25;
    SPBRGH = 0;
    RCSTAbits.SPEN = 1;
    RCSTAbits.CREN = 1;
    TXSTAbits.TXEN = 1;
}



#endif	/* UART_H */

