//------------------------------------------------------------------------------
//                                                                             *
//    Filename:      Sustituto.c                                               *
//    Fecha:         25/02/2020                                                *
//    Version:       v.1                                                       *
//    Author:        Nancy Alejandra Mazariegos                                *
//    Carnet:        17227                                                     *
//    Description:   Proyecto 1                                                *
//                                                                             *
//------------------------------------------------------------------------------
//*****************************************************************************
// Palabra de configuraci�n
//*****************************************************************************
// CONFIG1
#pragma config FOSC = EXTRC_NOCLKOUT// Oscillator Selection bits (RCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, RC on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

//*****************************************************************************
// Definici�n e importaci�n de librer�as
//*****************************************************************************
#include <xc.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "SPIRasp.h"
#include "LDC2.h"
#define _XTAL_FREQ 8000000
uint8_t Datoi,n;
uint8_t Color;
char DatoiC;
char TemperaturaC[20];
int color, temp, estado, ult;
void inicio(void);
void __interrupt() isr(void){
   if(SSPIF == 1){ 
       if (n == 0){
          color = spiRead();
          n=1; 
          SSPIF = 0;
      }
      else if (n == 1){
          temp = spiRead();
          n=2;
          SSPIF = 0;
      }
      else if (n == 2){
          estado = spiRead();
          n=3;
          SSPIF = 0;
      }
      else if (n == 3){
          ult = spiRead();
          n = 0;
          SSPIF = 0;
      }
      else{
          n=0;
          SSPIF = 0;
      }
        SSPIF = 0;
    }
}

void main(void) {
    inicio();
    Lcd_Init();
    Lcd_Clear(); 
    __delay_ms(250);
    Lcd_Set_Cursor(1,1);
    Lcd_Write_String("RGB");
    Lcd_Set_Cursor(1,5);
    Lcd_Write_String("TeC");
    Lcd_Set_Cursor(1,9);
    Lcd_Write_String("EnB");
    Lcd_Set_Cursor(1,13);
    Lcd_Write_String("FULL");
    while(1){
    
    if (color ==1){
        Lcd_Set_Cursor(2,1);
        Lcd_Write_String("Verd");
       // itoa(TemperaturaC,Temperatura,10);       //COnvertir variable en String 
    }    
    else if (color ==2){
        Lcd_Set_Cursor(2,1);
        Lcd_Write_String("Azul");
       // itoa(TemperaturaC,Temperatura,10);       //COnvertir variable en String 
    }
    else if (color ==3){
        Lcd_Set_Cursor(2,1);
        Lcd_Write_String("Rojo");
       // itoa(TemperaturaC,Temperatura,10);       //COnvertir variable en String 
    }
    else{
        Lcd_Set_Cursor(2,1);
        Lcd_Write_String("N--A");
    }
    
    itoa(TemperaturaC,temp,10);
    Lcd_Set_Cursor(2,6);
    Lcd_Write_String(TemperaturaC);
    
     if (estado==1){
        Lcd_Set_Cursor(2,9);
        Lcd_Write_String("ON ");
       // itoa(TemperaturaC,Temperatura,10);       //COnvertir variable en String 
    }    
    else if (estado ==2){
        Lcd_Set_Cursor(2,9);
        Lcd_Write_String("SRV");
       // itoa(TemperaturaC,Temperatura,10);       //COnvertir variable en String 
    }
    else if (estado ==3){
        Lcd_Set_Cursor(2,9);
        Lcd_Write_String("STP");
       // itoa(TemperaturaC,Temperatura,10);       //COnvertir variable en String 
    }
    else{
        Lcd_Set_Cursor(2,9);
        Lcd_Write_String("OFF");
    }
    
    if (ult >12){
        Lcd_Set_Cursor(2,13);
        Lcd_Write_String("FULL");
       // itoa(TemperaturaC,Temperatura,10);       //COnvertir variable en String 
    }    
    else if (ult<=12){
        Lcd_Set_Cursor(2,13);
        Lcd_Write_String("NOTY");
       // itoa(TemperaturaC,Temperatura,10);       //COnvertir variable en String 
    }
    
    
    }
    
    
}

void inicio(void){

    TRISA=0;//Data de LCD
    TRISE=0;//Habilitar LCD
    TRISB = 0;//
    TRISD=0;
    TRISCbits.TRISC3=1;
    TRISCbits.TRISC4=1;
    TRISBbits.TRISB6 = 0;//RS y RW de LCD.
    TRISBbits.TRISB7=0;
    INTCONbits.GIE = 1;         
    INTCONbits.PEIE = 1;        
    PIR1bits.SSPIF = 0;         
    PIE1bits.SSPIE = 1;         
    TRISAbits.TRISA5 = 1;       // Slave Select
    spiInit(SPI_SLAVE_SS_EN, SPI_DATA_SAMPLE_MIDDLE, SPI_CLOCK_IDLE_LOW, SPI_IDLE_2_ACTIVE);

}