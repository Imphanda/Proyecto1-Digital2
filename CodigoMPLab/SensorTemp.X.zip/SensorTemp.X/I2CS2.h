/* 
 * File:   i2cs2.h
 * Author: Nancy Mazariegos
 *
 * Created on February 25, 2020, 11:56 AM
 */

#ifndef I2CS2_H
#define	I2CS2_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* I2CS2_H */

